package com.example.mtm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mtm.model.Student;


public interface StudentRepository extends JpaRepository<Student,Integer>{

}
