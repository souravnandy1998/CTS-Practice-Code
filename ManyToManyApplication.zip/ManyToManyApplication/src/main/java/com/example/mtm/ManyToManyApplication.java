package com.example.mtm;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.mtm.model.Student;
import com.example.mtm.model.Course;
import com.example.mtm.repository.CourseRepository;
import com.example.mtm.repository.StudentRepository;

@SpringBootApplication
public class ManyToManyApplication {
	
	/*
	 * @Autowired private StudentRepository studentRepository;
	 * 
	 * @Autowired private CourseRepository courseRepository;
	 */
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(ManyToManyApplication.class, args);
	 StudentRepository studentRepository = context.getBean(StudentRepository.class);
		CourseRepository courseRepository = context.getBean(CourseRepository.class);
		// ManyToMany Mapping
				Student emp = new Student();
				emp.setS_name("Pavan Kumar");
				
				Student emp1 = new Student();
				emp1.setS_name("Kunal Bhoite");
				
				Student emp2 = new Student();
				emp2.setS_name("Rahul Das");
				
				Course s1 = new Course();
				s1.setC_name("Java");
				s1.setC_id(101);

				Course s2 = new Course();
				s2.setC_name("PHP");
				s2.setC_id(102);

				Course s3 = new Course();
				s3.setC_name("Python");
				s3.setC_id(103);

				List<Student> empShifts = s1.getStdList();
				empShifts.add(emp);
				empShifts.add(emp1);
				empShifts.add(emp2);

				List<Student> empShiftsOne = s2.getStdList();
				empShiftsOne.add(emp);
				empShiftsOne.add(emp1);
				empShiftsOne.add(emp2);

				List<Student> empShiftsTwo = s3.getStdList();
				empShiftsTwo.add(emp);
				empShiftsTwo.add(emp1);
				empShiftsTwo.add(emp2);
				
				List<Course> co=new ArrayList<>();
				co.add(s1);
				co.add(s2);
				co.add(s3);
				
				List<Course> co1=new ArrayList<>();
				co1.add(s1);
				co1.add(s2);
				co1.add(s3);
				
				List<Course> co2=new ArrayList<>();
				co2.add(s1);
				co2.add(s2);
				co2.add(s3);
				
				
				courseRepository.save(s1);
				courseRepository.save(s2);
				courseRepository.save(s3);
				
				
			}
	}


