package com.example.mtm.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="jpa_course")
public class Course {
	@Id
	private int c_id;  
	private String c_name;  
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Student> stdList=new ArrayList<>();
	
	public int getC_id() {
		return c_id;
	}
	public void setC_id(int c_id) {
		this.c_id = c_id;
	}
	public String getC_name() {
		return c_name;
	}
	public void setC_name(String c_name) {
		this.c_name = c_name;
	}
	
	public List<Student> getStdList() {
		return stdList;
	}
	public void setStdList(List<Student> stdList) {
		this.stdList = stdList;
	}
	public Course(int c_id, String c_name, List<Student> stdList) {
		super();
		this.c_id = c_id;
		this.c_name = c_name;
		this.stdList = stdList;
	}
	public Course() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Course [c_id=" + c_id + ", c_name=" + c_name + ", stdList=" + stdList + "]";
	}
	
	
}
