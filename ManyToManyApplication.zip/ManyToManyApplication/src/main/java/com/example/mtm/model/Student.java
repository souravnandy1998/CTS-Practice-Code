package com.example.mtm.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="jpa_student")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int s_id;
	private String s_name;
	@ManyToMany(mappedBy ="stdList",cascade = CascadeType.ALL)  
	private List<Course> cour=new ArrayList<>();
	
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int s_id) {
		this.s_id = s_id;
	}
	public String getS_name() {
		return s_name;
	}
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	public List<Course> getCour() {
		return cour;
	}
	public void setCour(List<Course> cour) {
		this.cour = cour;
	}
	public Student(int s_id, String s_name, List<Course> cour) {
		super();
		this.s_id = s_id;
		this.s_name = s_name;
		this.cour = cour;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [s_id=" + s_id + ", s_name=" + s_name + ", cour=" + cour + "]";
	}
	
	
}
