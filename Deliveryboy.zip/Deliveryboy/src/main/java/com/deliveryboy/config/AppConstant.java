package com.deliveryboy.config;

public class AppConstant {

	public static final String LOCATION_TOPIC_NAME="location-update-topic";
}
