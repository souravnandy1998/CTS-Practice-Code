package com.spring.crud;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.spring.crud.model.Employee;
import com.spring.crud.repository.EmployeeRepository;

@SpringBootApplication
public class SpringCrudApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringCrudApplication.class, args);
	}
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Employee emp1=new Employee();
		emp1.setFirstName("Sourav");
		emp1.setLastName("Nandy");
		emp1.setEmailId("sourav@gmail.com");
		employeeRepository.save(emp1);
		
		Employee emp2=new Employee();
		emp2.setFirstName("Kamala");
		emp2.setLastName("Prasad");
		emp2.setEmailId("kamrav@gmail.com");
		employeeRepository.save(emp2);
		
		
		
	}

}
