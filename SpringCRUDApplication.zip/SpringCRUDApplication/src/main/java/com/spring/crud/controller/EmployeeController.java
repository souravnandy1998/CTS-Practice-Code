package com.spring.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.crud.exception.ResourcenotFoundException;
import com.spring.crud.model.Employee;

import com.spring.crud.repository.EmployeeRepository;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@GetMapping
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}
	
	@GetMapping(path="/{empID}",produces = { MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<Employee> getEmployeeById(@PathVariable Long empID)
	{
		/*if(employeeRepository.findById(empID) != null) {
		return new ResponseEntity<>(employeeRepository.getOne(empID),HttpStatus.OK);}
		else {
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}*/
		
		Employee emp=employeeRepository.findById(empID).orElseThrow(()->new ResourcenotFoundException("Employee not exist with ths id "+empID));
		return ResponseEntity.ok(emp);
	}
	
	@PostMapping
	public Employee createEmployee(@RequestBody Employee emp)
	{
		
		return employeeRepository.save(emp);
	}
	
	@PutMapping(path="/{empID}",produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
			consumes= {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity<Employee> updateEmployee(@PathVariable long empID,@RequestBody Employee employeeDetails)
	{
		Employee updateEmp=employeeRepository.findById(empID).orElseThrow(()->new ResourcenotFoundException("Employee not exist with ths id "+empID));
		updateEmp.setFirstName(employeeDetails.getFirstName());
		updateEmp.setLastName(employeeDetails.getLastName());
		updateEmp.setEmailId(employeeDetails.getEmailId());
		employeeRepository.save(updateEmp);
		return ResponseEntity.ok(updateEmp);
	}
	
	@DeleteMapping(path="/{empID}")
	public ResponseEntity<HttpStatus> deleteEmployee(@PathVariable long empID){
		
		Employee emp=employeeRepository.findById(empID).orElseThrow(()->new ResourcenotFoundException("Employee not exist with ths id "+empID));
		employeeRepository.delete(emp);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}
