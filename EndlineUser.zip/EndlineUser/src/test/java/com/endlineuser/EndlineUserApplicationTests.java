package com.endlineuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndlineUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
