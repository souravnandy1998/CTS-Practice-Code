package com.endlineuser.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.KafkaListener;

@Configuration
public class KafkaConfig {
	
	
	@KafkaListener(topics =Appconstant.LOCATION_TOPIC_NAME ,groupId=Appconstant.GROUP_ID)
	public void updateLocation(String location)
	{
		System.out.println(location);
	}

}
