package com.endlineuser.config;

public class Appconstant {

	public static final String LOCATION_TOPIC_NAME="location-update-topic";
	public static final String GROUP_ID="group-1";
}
