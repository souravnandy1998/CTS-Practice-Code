import java.util.List;

public class FP01StructeredWay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> numbers=List.of(12,9,13,3,12,5,6,8,21);
		//printAllNumbers(numbers);
		printEvenNumbers(numbers);

	}

	private static void printEvenNumbers(List<Integer> numbers) {
		for (int number:numbers)
		{
			if(number%2==0)
				System.out.println(number);
		}
		
	}

	private static void printAllNumbers(List<Integer> numbers) {
		for (int number: numbers)
		{
			System.out.println(number);
		}
		
	}

}
