
public class ValidationConfig {

}
