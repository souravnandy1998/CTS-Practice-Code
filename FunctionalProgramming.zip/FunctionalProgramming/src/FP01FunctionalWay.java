import java.util.List;
import java.util.stream.Collectors;

public class FP01FunctionalWay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> numbers = List.of(12, 9, 13, 3, 14, 5, 6, 8, 21);
		List<String> courses = List.of("Spring", "API", "DJANGO", "Spring Boot", "Azure");
		// printAllNumbers(numbers);
		// printEvenNumbers(numbers);
		//printSquareofEvenNumbers(numbers);
		// printContainsSpring(courses);
		//printFiveLetter(courses);
		printnumberofCharacters(courses);
	}

	private static void printnumberofCharacters(List<String> courses) {
		courses.stream().map(e->e.length()).forEach(System.out::println);;
		
	}

	private static void printSquareofEvenNumbers(List<Integer> numbers) {
		// TODO Auto-generated method stub
		numbers.stream().filter(e -> e % 2 == 0).map(x->x*x).forEach(System.out::println);
	}

	private static void printFiveLetter(List<String> courses) {
		courses.stream().filter(e -> e.length() >= 5).forEach(System.out::println);

	}

	private static void printContainsSpring(List<String> courses) {
		courses.stream().filter(e -> e.contains("Spring")).forEach(System.out::println);

	}

	private static void printAllNumbers(List<Integer> numbers) {
		numbers.stream().forEach(System.out::println);

	}

	private static void printEvenNumbers(List<Integer> numbers) {
		List<Integer> n = numbers.stream().filter(e -> e % 2 == 0).collect(Collectors.toList());
		System.out.println(n);
	}

}
