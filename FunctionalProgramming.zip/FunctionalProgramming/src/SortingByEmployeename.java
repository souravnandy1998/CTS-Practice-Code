import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class SortingByEmployeename {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> emplist=Arrays.asList(new Employee(123,"Sourav"),
				new Employee(124,"Goutam"),
				new Employee(128,"Mohua"),
				new Employee(126,"Duniya"));
		
		emplist.stream().sorted(Comparator.comparing(Employee::getEmpName)).forEach(System.out::println);	
	//emplist.stream().sorted(Comparator.comparing(Employee::getEmpName,Comparator.reverseOrder())).forEach(System.out::println);	
	}

}
