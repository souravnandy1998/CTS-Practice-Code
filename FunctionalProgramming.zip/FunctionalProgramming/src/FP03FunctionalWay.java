import java.util.Comparator;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class FP03FunctionalWay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> numbers = List.of(12, 9, 3, 5, 6, 8, 6);
		
		Predicate<Integer> Evenpredicate = e->e%2==0;
		Function<Integer, Integer> Squaremapper = x->x*x;
		Consumer<Integer> SysoutConsumer = System.out::println;
		
		//numbers.stream().filter(Evenpredicate).map(Squaremapper).forEach(SysoutConsumer);
		
		BinaryOperator<Integer> sumOfaccumulator = Integer::sum;
		
		BinaryOperator<Integer> sumOfaccumulator2=new BinaryOperator<Integer>() {

			@Override
			public Integer apply(Integer t, Integer u) {
				
				return t+u;
			}
		
		};
		
		int sum=numbers.stream().reduce(0,sumOfaccumulator2);
		System.out.println(sum);
	}
}
