import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FP02FunctionalWay {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> numbers = List.of(12, 9, 3, 5, 6, 8, 6);
		List<String> courses = List.of("Spring", "API", "DJANGO", "Spring Boot", "Azure");
		
		//int sum=addListFunctional(numbers);
		//System.out.println(sum);
		//int sumofSquare=SumofSqaurenumber(numbers);
		//System.out.println(sumofSquare);
		//int sumofCube=SumofCubenumber(numbers);
		//System.out.println(sumofCube);
		int sumofOdd=sumofOddnumber(numbers);
		//System.out.println(sumofOdd);
		List<Integer> evennumber=listofEvennumbers(numbers);
		//System.out.println(evennumber);
		
		List<Integer> length=listofLengthCourse(courses);
		System.out.println(length);
		
		//numbers.stream().distinct().forEach(System.out::println);
		//numbers.stream().sorted().forEach(System.out::println);
		//courses.stream().sorted(Comparator.naturalOrder()).forEach(System.out::println);
		//courses.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		//courses.stream().sorted(Comparator.comparing(str->str.length())).forEach(System.out::println);
	}
	
	private static List<Integer> listofLengthCourse(List<String> courses) {
		return courses.stream().map(x->x.length()).collect(Collectors.toList());
	}

	private static List<Integer> listofEvennumbers(List<Integer> numbers) {
		return numbers.stream().filter(x->x%2==0).collect(Collectors.toList());
		
	}

	private static Integer sumofOddnumber(List<Integer> numbers) {
		return numbers.stream().filter(e->e%2==1).reduce(0,Integer::sum);	
	}

	private static int SumofCubenumber(List<Integer> numbers) {
		return numbers.stream().map(x->x*x*x).reduce(0,Integer::sum);
	}

	private static Integer SumofSqaurenumber(List<Integer> numbers) {
		return numbers.stream().map(x->x*x).reduce(0,Integer::sum);
		
	}

	/*
	 * private static int sum(int a,int b) { return a+b; }
	 */

	private static int addListFunctional(List<Integer> numbers) {
		
		//return numbers.stream().reduce(0,FP02FunctionalWay::sum);
		//return numbers.stream().reduce(0,(x,y)->x+y);
		return numbers.stream().reduce(0,Integer::sum);
	}

	

}
