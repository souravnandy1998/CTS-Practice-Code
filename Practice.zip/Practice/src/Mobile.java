
public class Mobile {

	String model;
	int price;
	static String name;
	
	public void show()
	{
		System.out.println("Model: "+model+":"+"price: "+price+"name: "+name);
	}
	
	public static void show1()
	{
		System.out.println("Inside Static method");
	}
	
	public static void show2(Mobile obj1)
	{
		System.out.println("Model: "+obj1.model+":"+"price: "+obj1.price+"name: "+name);
	}
}
