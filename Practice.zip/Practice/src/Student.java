
public class Student {

	private int id;
	private int mark;
	public Student(int id, int mark) {
		super();
		this.id = id;
		this.mark = mark;
	}
	
}
