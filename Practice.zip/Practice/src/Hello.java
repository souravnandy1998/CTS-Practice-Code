import java.time.*;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAdjuster;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;


public class Hello{

	public static void main(String[] args) {
		
		Integer n=null;
		Integer m=new Integer(10);
		//Optional<Integer> obj1=Optional.ofNullable(n);
		Optional<Integer> obj2=Optional.of(m);
		//System.out.println(obj1);
		System.out.println(obj2);
	}

	

}
