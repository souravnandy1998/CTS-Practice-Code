import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Oddeven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> arr=new ArrayList<>();
		arr.add(10);
		arr.add(13);
		arr.add(15);
		arr.add(14);
		List<Integer> num=arr.stream().filter(e->e%2==0).collect(Collectors.toList());
		System.out.println(num);
		
	}

}
