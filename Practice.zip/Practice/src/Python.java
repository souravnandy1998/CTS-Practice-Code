public interface Python{
    default void showDescription(){
        System.out.println("Perl is oop language");
    }
}