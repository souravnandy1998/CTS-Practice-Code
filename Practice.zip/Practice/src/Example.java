import java.util.ArrayList;
import java.util.List;

public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Student> sl=new ArrayList<Student>();
		sl.add(new Student(1, 87));
		sl.add(new Student(2, 67));
		sl.add(new Student(3, 77));
		sl.add(new Student(4, 57));
		sl.add(new Student(5, 47));
		//Double am=sl.stream().collect(Collectors.avg);
		//System.out.println(am);
	}

}
