
public class Students 
	{
		int roll;
		String name;
		int marks;
		@Override
		public String toString() {
			return "Students [roll=" + roll + ", name=" + name + ", marks=" + marks + "]";
		}
	}



