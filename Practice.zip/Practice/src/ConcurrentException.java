import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ConcurrentException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> mobiles=new ArrayList<>();
		mobiles.add("Redmi");
		mobiles.add("Realme");
		mobiles.add("Oppo");
		mobiles.add("Moto");
		mobiles.add("Apple");
		
		System.out.println("List of Mobiles: "+ mobiles);
		/*for(String phone:mobiles)
		{
			phone.equals("Oppo");
			mobiles.remove(phone);
		}
		*/
		Iterator<String> itr=mobiles.iterator();
		while(itr.hasNext()){
			String phone=itr.next();
			if(phone.equals("Oppo"))
			{
				itr.remove();
			}
		}
		System.out.println("List of Mobiles after remove: "+ mobiles);
	}

}
