
public interface MyInterface {

	default void showMethod()
	{
		System.out.println("MyInterface method");
	}
}
