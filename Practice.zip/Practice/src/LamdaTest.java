


public class LamdaTest implements Python,Perl{

	@Override
	public void showDescription() {
		// TODO Auto-generated method stub
		Python.super.showDescription();
	}
	
	/*
	 * public void showDescription() {
	 * System.out.println("Both are computer language"); }
	 */}