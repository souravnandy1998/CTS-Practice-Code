
public class Arraycreation {

	public static void main(String[] args) {
		// Create single dimensional array with random number
		/*
		 * int num1[]=new int[5]; for(int i=0;i<num1.length;i++) {
		 * num1[i]=(int)(Math.random()*100); System.out.print(num1[i]+ " "); }
		 */	
		//create multidimensional array
		
		int num2[][]=new int[3][4];
		int random=0;
		for (int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				num2[i][j]=(int)(Math.random()*10);
				//System.out.print(num2[i][j]+" ");
			}
			System.out.println();
		}
		//with for-each loop
		for(int n[]: num2)
		{
			for(int m:n)
			{
				System.out.print(m+" ");
			}
			System.out.println();
		}
	}
}
