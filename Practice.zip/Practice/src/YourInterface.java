import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class YourInterface {
	
	public static void main(String args[]) {
		
		List<String> la=Arrays.asList("Java","Ruby","PHP");
		String l=la.stream().map(String::valueOf).collect(Collectors.joining(",","{","}"));
		System.out.println(l);
	}
	
}
