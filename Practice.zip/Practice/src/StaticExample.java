
public class StaticExample {

	public static void main(String args[])
	{
		Mobile obj1=new Mobile();
		obj1.model="Samsung";
		obj1.price=20000;
		
		Mobile obj2=new Mobile();
		obj2.model="Apple";
		obj2.price=50000;
		
		Mobile.name="Smartphone";
		obj1.show();
		obj2.show();
		Mobile.show1();
		Mobile.show2(obj1);
		
	}
}
