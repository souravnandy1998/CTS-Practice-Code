import java.util.Scanner;

public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st number: ");
		a=sc.nextInt();
		System.out.println("Enter the 2nd number: ");
		b=sc.nextInt();
		
		sum=a+b;
		System.out.println("The result is: "+sum);
		System.out.println("Hello World");
	}

}
