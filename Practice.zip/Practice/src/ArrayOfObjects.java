import java.util.Iterator;

//class Students()
//{
//	int roll;
//	String name;
//	int marks;
//}

public class ArrayOfObjects {

	public static void main(String[] args) {
		 Students s1=new Students();
		 s1.roll=1;
		 s1.name="Sourav";
		 s1.marks=98;
		 
		 Students s2=new Students();
		 s2.roll=2;
		 s2.name="Rahul";
		 s2.marks=81;
		 
		 Students s3=new Students();
		 s3.roll=3;
		 s3.name="Sachin";
		 s3.marks=39;
		 
		 Students arrayStudent[]=new Students[3];
		 arrayStudent[0]=s1;
		 arrayStudent[1]=s2;
		 arrayStudent[2]=s3;
		 
		 for(int i=0;i<arrayStudent.length;i++)
		 {
			 System.out.println(arrayStudent[i]);
		}
		 
	}

}
