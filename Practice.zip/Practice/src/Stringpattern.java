import java.util.HashMap;
import java.util.Map;

public class Stringpattern {
	public static void main(String[] arr) {
		String s="aaaaaaabbbtttt";
		String r="";
		
		HashMap<Character, Integer> hm = new HashMap<Character, Integer>();
		
		for(int i=0;i<s.length();i++) {
			
			if(hm.containsKey(s.charAt(i))) {
				hm.put(s.charAt(i), hm.get(s.charAt(i))+1);
			}
			else {
				hm.put(s.charAt(i), 1);
			}
			
		}
		
		for(Map.Entry<Character, Integer> entry : hm.entrySet()){
			r =r+entry.getKey()+entry.getValue();
		}
		
		System.out.println(r);
	}
}
