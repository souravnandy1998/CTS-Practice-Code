import java.util.Arrays;
import java.util.List;

public class Findnumbersinanarraystartingwithspecificdigit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> ml=Arrays.asList(1234,1235,1236,43232,12443,5646334,1231412,6798796,8987);
		ml.stream().map(s->s+"").filter(s->s.startsWith("1")).forEach(System.out::println);
		
	}

}
