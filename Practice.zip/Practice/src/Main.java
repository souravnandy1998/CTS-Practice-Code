
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale.LanguageRange;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream; 

public class Main {
	
	public static void main(String args[]) {
	
	List<Integer> integerLst=IntStream.range(1, 100)
			.boxed()
			.collect(Collectors.toCollection(ArrayList::new));
		
	}
}