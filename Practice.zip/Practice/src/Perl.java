public interface Perl{
    default void showDescription(){
        System.out.println("Perl is not oop");
    }
}