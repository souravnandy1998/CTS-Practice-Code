import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

public class MyClass {

	public static void main(String args[])
	{
		List<String> dataList=Arrays.asList("code","I","Java");
		List<String> sortedData=dataList.stream().sorted(String::compareTo).collect(Collectors.toList());
		System.out.println(sortedData);
	}
}

